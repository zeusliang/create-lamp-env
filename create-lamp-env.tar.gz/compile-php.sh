#!/bin/bash

# install php
if [ ! -d /var/local/src ]
then
mkdir /var/local/src
fi
cd /var/local/src
wget http://cn2.php.net/get/php-7.2.10.tar.gz/from/this/mirror -O php-7.2.10.tar.gz
tar xf php-7.2.10.tar.gz

if [ ! -d /usr/local/etc ]
then
mkdir /usr/local/etc
fi

mkdir /usr/local/etc/php
mkdir /usr/local/etc/php/conf.d


cd /var/local/src/php-7.2.10
'./configure'  \
'--build=x86_64-linux-gnu' \
'--with-config-file-path=/usr/local/etc/php' \
'--with-config-file-scan-dir=/usr/local/etc/php/conf.d' \
'--enable-option-checking=fatal' \
'--with-mhash' \
'--enable-ftp' \
'--enable-mbstring' \
'--enable-mysqlnd' \
'--with-password-argon2' \
'--with-sodium=shared' \
'--with-curl' \
'--with-libedit' \
'--with-openssl' \
'--with-zlib' \
'--with-libdir=lib/x86_64-linux-gnu' \
'--disable-cgi' \
'build_alias=x86_64-linux-gnu' \
'--with-pdo-mysql=mysqlnd' \
'--with-gd' \
'--with-freetype-dir' \
'--with-jpeg-dir' \
'--with-png-dir' \
'--with-zlib-dir' \
'--with-apxs2=/usr/local/apache2/bin/apxs'
make install
cp php.ini-production /usr/local/etc/php/php.ini

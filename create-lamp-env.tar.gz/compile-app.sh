#!/usr/bin/bash

set -e
# add speed repo
source  ./163-repo.sh

# install compile tools
source ./compile-tools.sh

# install httpd
source ./compile-httpd.sh

# install php
source ./compile-php.sh

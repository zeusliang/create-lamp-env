#!/usr/bin/bash

set -e
if [ ! -f /usr/local/apache2/bin/apachectl ]
then
# download httpd
if [ ! -d  /var/local/src ]
then
mkdir /var/local/src
fi
mkdir /var/local/src/httpd
cd /var/local/src/httpd

wget -q https://ftp.pcre.org/pub/pcre/pcre-8.40.tar.gz

wget -q http://mirrors.tuna.tsinghua.edu.cn/apache//httpd/httpd-2.4.34.tar.gz

wget -q http://mirrors.tuna.tsinghua.edu.cn/apache//apr/apr-1.6.5.tar.gz

wget -q http://mirrors.tuna.tsinghua.edu.cn/apache//apr/apr-util-1.6.1.tar.gz

# compile
tar xf pcre-8.40.tar.gz 
cd pcre-8.40 
./configure && make install
cd ..

tar xf apr-1.6.5.tar.gz 
tar xf apr-util-1.6.1.tar.gz 
tar xf httpd-2.4.34.tar.gz 
if [ ! -d httpd-2.4.34/srclib/apr ] && [ ! -d httpd-2.4.34/srclib/apr-util ]
then
mv  apr-1.6.5 httpd-2.4.34/srclib/apr
mv  apr-util-1.6.1 httpd-2.4.34/srclib/apr-util 
fi
cd httpd-2.4.34 
./configure --enable-so  \
--enable-rewrite
make install

#set auto start for apache
if [  ! -f /etc/init.d/httpd ]
then
ln -s /usr/local/apache2/bin/apachectl /etc/init.d/httpd
sed -i '2i\#chkconfig: 2345 10 90' /etc/rc.d/init.d/httpd
sed -i '3i\#description: Activates/Deactivates Apache Web Server' /etc/rc.d/init.d/httpd

chkconfig --add httpd
chkconfig httpd on
fi
fi

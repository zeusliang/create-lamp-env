#/bin/bash

yum -y install gcc-c++
yum -y install expat-devel
yum -y install make 
yum -y install libtool 
yum -y install libxml2 libxml2-devel
yum -y install openssl-devel 
yum -y install libcurl-devel 
yum -y install libjpeg-turbo-devel 
yum -y install libpng-devel
yum -y install freetype 
yum -y install freetype-devel 
yum -y install libedit 
yum -y install libedit-devel 
yum -y install argon2 
yum -y install libargon2-devel
yum -y install libsodium libsodium-devel
